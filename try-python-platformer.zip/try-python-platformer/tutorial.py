import os
import random
import math
import pygame
#these are used to dynamically load the spread sheet. by using path and such
from os import listdir
from os.path import isfile,join

pygame.init()  #initializing the pygame module.

#sets the caption at the top of the screen.
pygame.display.set_caption("platformer")
WIDTH,HEIGHT=1000,800  
FPS=60
PLAYER_VEL=5   #SPEED AT WHICH OUR PLAYER MOVES ON THE WINDOW.
window=pygame.display.set_mode((WIDTH,HEIGHT))  #this will create the pygame window for us

def flip(sprites):
    return [pygame.transform.flip(sprite,True,False) for sprite in sprites]

def load_sprite_sheets(dir1,dir2,width,height,direction=False):
    path=join("assets",dir1,dir2)
    images=[f for f in listdir(path) if isfile(join(path,f))]  # list all files in that path

    all_sprites={} #key is the animation type and the values are all of the images

    for image in images:
        sprite_sheet=pygame.image.load(join(path,image)).convert_alpha()  # to load transparent images
        sprites=[]
        for i in range(sprite_sheet.get_width()//width):     #so that each frame of the chararter can appear one by one by dividing the image  by widht of 1 character
            surface=pygame.Surface((width,height),pygame.SRCALPHA,32)
            rect=pygame.Rect(i*width,0,width,height)  #i*widht,0 gives the top left coordinate of the img to be drawn
            surface.blit(sprite_sheet,(0,0),rect)   #tells to draw rect frame from sprite sheet at top left corner of the screen created
            sprites.append(pygame.transform.scale2x(surface))
        
        if direction:
            #for every image frame we want one in right ,i.e default and another in left
            all_sprites[image.replace(".png","")+"_right"]=sprites
            all_sprites[image.replace(".png","")+"_left"]=flip(sprites)
        else:
            all_sprites[image.replace(".png","")]=sprites
    
    return all_sprites

def get_block(size):    #size tells us size of terrain to be 
    path=join("assets","Terrain","Terrain.png")
    image=pygame.image.load(path).convert_alpha()
    surface=pygame.Surface((size,size),pygame.SRCALPHA,32)    # we create a transparent screen of that size
    rect=pygame.Rect(96,0,size,size) #beacuse in our image our required terrain start 96px to left
    surface.blit(image,(0,0),rect)   #then we blit our image to the surface but only in the area of the rect
    return pygame.transform.scale2x(surface) 

#we inherit from pygame.sprite.Sprite
#sprite has a method which tells us if the sprties are colliding with each other 

class Player(pygame.sprite.Sprite):
    COLOR=(255,0,0)
    GRAVITY=1
    SPRITES=load_sprite_sheets("Maincharacters","MaskDude",32,32,True)
    ANIMATION_DELAY=5

    def __init__(self,x,y,width,height):
        super().__init__()
        #rect is just kind of a tuple holding 4 values
        self.rect=pygame.Rect(x,y,width,height) #we just put the values on the rectangle ,thus easier to use
        #tells us how fast we are moving our object in x and y direction until we change it.
        self.x_vel=0  ;self.y_vel=0
        self.mask=None
        self.direction="left"
        self.animation_count=0
        self.fallcount=0  #this will tell us how for how long we have been falling
        self.jump_count=0
        self.hit=False
        self.hit_count=0

    def jump(self):
        self.y_vel=-self.GRAVITY*8
        self.animation_count=0
        self.jump_count+=1
        if self.jump_count==1:
            self.fallcount=0    # we are removing any gravity for the first jump
        
        
        


    def move(self,dx,dy):
        self.rect.x+=dx  # basically displace the x pos by dx
        self.rect.y+=dy

    def make_hit(self):
        self.hit=True
        self.hit_count=0


    def move_left(self,vel):
        self.x_vel=-vel #negative so that it goes in -x axis
        if self.direction!="left": # so that we know which direction we are facing in
            self.direction="left"
            self.animation_count=0

    def move_right(self,vel):
        self.x_vel=vel
        if self.direction!="right":
            self.direction="right"
            self.animation_count=0

    def loop(self,fps):
        self.y_vel+= min(1,(self.fallcount/fps)*self.GRAVITY)  #as for 1 sec fall , self.fallcount will be equal to fps
        self.move(self.x_vel,self.y_vel) #move every single frame
        self.fallcount+=1
        if self.hit:
            self.hit_count+=1
        
        if self.hit_count>fps*2:
            self.hit=False
            self.hit_count=0
        self.update_sprite()

    def landed(self):
        self.fallcount=0
        self.y_vel=0
        self.jump_count=0
    
    def hit_head(self):
        self.count=0
        self.y_vel*=-1

    def update_sprite(self):
        sprite_sheet="idle"
        if self.hit:
            sprite_sheet="hit"
        if self.y_vel<0:
            if self.jump_count==1:
                sprite_sheet="jump"
            elif self.jump_count==2:
                sprite_sheet="double_jump"
        
        elif self.y_vel>self.GRAVITY*2:
            sprite_sheet="fall" 

        if self.x_vel != 0:
            sprite_sheet="run"
        
        sprite_sheet_name=sprite_sheet+"_"+self.direction  
        sprites=self.SPRITES[sprite_sheet_name]  #now we need to loop through this every frame
        sprite_index=(self.animation_count//self.ANIMATION_DELAY) % len(sprites) #tell us which nth frame to show at a given time
        self.sprite=sprites[sprite_index]  
        self.animation_count+=1
        self.update()

    def update(self):
        self.rect= self.sprite.get_rect(topleft=(self.rect.x,self.rect.y))  # the rect is constantly updated based on size of the current sprite
        self.mask=pygame.mask.from_surface(self.sprite)  #mask allows us to do picture perfect collision as the sprite uses this rect and mask function for collision

    def draw(self,win,offset_x): #handles drawing
        win.blit(self.sprite,(self.rect.x-offset_x,self.rect.y))

#the parent class for any kind of object drawn on screen other than player
class Object(pygame.sprite.Sprite):
    def __init__(self,x,y,width,height,name=None):
        super().__init__()
        self.rect=pygame.Rect(x,y,width,height)
        self.image=pygame.Surface((width,height),pygame.SRCALPHA)
        self.width=width
        self.height=height
        self.name=name
    
    def draw(self,win,offset_x):
        win.blit(self.image,(self.rect.x-offset_x,self.rect.y))



class Block(Object):
    def __init__(self,x,y,size):
        super().__init__(x,y,size,size)  # we are drawing sq so width and height same
        block=get_block(size)
        self.image.blit(block,(0,0))   
        self.mask=pygame.mask.from_surface(self.image)
    
class Fire(Object):
    ANIMATION_DELAY=3
    def __init__(self,x,y,width,height):
        super().__init__(x,y,width,height,"fire")
        self.fire=load_sprite_sheets("Traps","Fire",width,height)  #the func which takes sprite sheet name and gives us all the frame
        self.image=self.fire['off'][0]
        self.mask=pygame.mask.from_surface(self.image)
        self.animation_count=0
        self.animation_name='off'

    def on(self):
        self.animation_name='on'
    
    def off(self):
        self.animation_name='off'
    
    def loop(self):     #just like our player loop
        
        sprites=self.fire[self.animation_name]  #now we need to loop through this every frame
        sprite_index=(self.animation_count//self.ANIMATION_DELAY) % len(sprites) #tell us which nth frame to show at a given time
        self.image=sprites[sprite_index]  
        self.animation_count+=1

        #updating rect and mask for collison
        self.rect= self.image.get_rect(topleft=(self.rect.x,self.rect.y))  # the rect is constantly updated based on size of the current sprite
        self.mask=pygame.mask.from_surface(self.image)  #mask allows us to do picture perfect collision as the sprite uses this rect and mask function for collision

        if self.animation_count//self.ANIMATION_DELAY>len(sprites):     
            self.animation_count=0
#this function will return the list of tile pos and the tile img which we need for terrain of given size
def get_background(name):  #name is the color of background u want
    
    #join is used for creating the path with a variable in it
    image=pygame.image.load(join("assets","Background",name))  
    _,_,width,height=image.get_rect(); #gives x,y, width and height
    tiles=[] #wiill store the x,y pos of topleft corner of each tile 
    for i in range(WIDTH//width+1):
        for j in range(HEIGHT//height+1):
            #here pos gives us the position of the top left side of the img
            #as in pygame images are drawn from top left
            pos=(i*width,j*height)
            tiles.append(pos)

    return tiles,image

#this will draw all of our drawing
def draw(window,background,bg_image,player,objects,offset_x):
    for tile in background:
        window.blit(bg_image,tile)  #we will draw the bg_image at the tile
    
    for obj in objects:
        obj.draw(window,offset_x) # we will draw all the objects from blocks on the windows
    
    player.draw(window,offset_x)  
    pygame.display.update() #to update the screen once the drawing is complete

def collide(player,objects,dx):
    player.move(dx,0)  
    player.update()   #updating mask and collsion
    collided_object=None
    for obj in objects:    
        if pygame.sprite.collide_mask(player,obj):   #basically checking if by moving in the same direction , you are going to hit a block or not.
            collided_object=obj            #if they collide then we update our collided object
            break

    player.move(-dx,0)  #moving to original pos
    player.update()
    return collided_object



def handle_vertical_collision(player,objects,dy):
    collided_object=[]
    for obj in objects:
        if pygame.sprite.collide_mask(player,obj):   #tells us if we are colliding with an object
            if dy>0:
                player.rect.bottom=obj.rect.top  #basically if i am mooving down on screen then we take bottom of our player and place it on top of our collided obj
                player.landed()
            elif dy<0:
                player.rect.top=obj.rect.bottom
                player.hit_head()

            collided_object.append(obj)
    return collided_object    #reutrns collided object to know if we hit our head with fire or something



def handle_move(player,objects):
    keys=pygame.key.get_pressed() #tells us of all keys being pressed on keyboard

    player.x_vel=0 # so that we only move while holding key

    collide_left=collide(player,objects,-PLAYER_VEL*2)
    collide_right=collide(player,objects,PLAYER_VEL*2)
    if keys[pygame.K_LEFT] and not collide_left:   #if left arrow key pressed and not gonna collide  , then move left
        player.move_left(PLAYER_VEL)
    if keys[pygame.K_RIGHT] and not collide_right:   #if left arrow key pressed and not gonna collide , then move left
        player.move_right(PLAYER_VEL)
    
    vertical_collide=handle_vertical_collision(player,objects,player.y_vel)
    to_check=[collide_left,collide_right,*vertical_collide]
    for obj in to_check:
        if obj and obj.name=="fire":     #we are going through all the objects we collided with and if we collided with fire then we run hit func
            player.make_hit()

#here we will handle our event loop
def main(window):
    clock=pygame.time.Clock() 
    background,bg_image=get_background("Blue.png")
    block_size=96
    player=Player(100,100,50,50)
    #basically block goes to the left and right of current screen and each of sizd block_size
    fire=Fire(100,HEIGHT-block_size-64,16,32)
    fire.on()
    floor=[Block(i*block_size,HEIGHT-block_size,block_size) for i in range(-WIDTH//block_size,WIDTH*2//block_size)]
    objects=[*floor,Block(0,HEIGHT-block_size*2,block_size),
             Block(block_size*4,HEIGHT-block_size*3,block_size),fire]
    

    offset_x=0 
    scroll_area_width=200
    
    run=True
    while run:
        clock.tick(FPS)  #makes sure that our while loop runs 60 times per second

        #here we will check for whatever event is triggered by the user
        for event in pygame.event.get():

            #here we stop the event loop once the user quits the app
            if event.type==pygame.QUIT:
                run=False
                break
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_SPACE and player.jump_count<2:
                    player.jump()

        player.loop(FPS)   #because loop is basically what moves our player
        fire.loop()
        handle_move(player,objects)
        draw(window,background,bg_image,player,objects,offset_x)

        if (((player.rect.right-offset_x>= WIDTH-scroll_area_width) and player.x_vel>0) or
        ((player.rect.left-offset_x<= scroll_area_width) and player.x_vel<0)):
            offset_x+=player.x_vel
    
    pygame.quit()
    quit()


# #this is so that we run our main function only if we execute file directly
# #otherwise if we import this code , we don't want main func to run.
if __name__=="__main__":
    main(window)